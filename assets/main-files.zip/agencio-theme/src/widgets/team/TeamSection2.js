import React, { Component } from 'react';

class TeamSection2 extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (

            <div className="row">
                <div className="col-md-6 col-12">
                    <div className="accordion">
                        <div className="card">
                            <div className="card-header">
                                <h6 className="mb-0">
                                    consectetur adipisicing elit, sed ?
                            </h6>
                            </div>
                            <div className="card-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodas temporo incididunt ut labore et dolore magna aliqua.</div>
                        </div>
                    </div>
                </div>
                <div className="col-md-6 col-12 mt-md-0 mt-5">
                    <div className="accordion">
                        <div className="card">
                            <div className="card-header">
                                <h6 className="mb-0">
                                    consectetur adipisicing elit, sed ?
                             </h6>
                            </div>
                            <div className="card-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodas temporo incididunt ut labore et dolore magna aliqua.</div>
                        </div>
                    </div>
                </div>
                <div className="col-md-6 col-12 mt-5">
                    <div className="accordion">
                        <div className="card">
                            <div className="card-header">
                                <h6 className="mb-0">
                                    consectetur adipisicing elit, sed ?
                                </h6>
                            </div>
                            <div className="card-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodas temporo incididunt ut labore et dolore magna aliqua.</div>
                        </div>
                    </div>
                </div>
                <div className="col-md-6 col-12 mt-5">
                    <div className="accordion">
                        <div className="card">
                            <div className="card-header">
                                <h6 className="mb-0">
                                    consectetur adipisicing elit, sed ?
                            </h6>
                            </div>
                            <div className="card-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodas temporo incididunt ut labore et dolore magna aliqua.</div>
                        </div>
                    </div>
                </div>
                <div className="col-md-6 col-12 mt-5">
                    <div className="accordion">
                        <div className="card">
                            <div className="card-header">
                                <h6 className="mb-0">
                                    consectetur adipisicing elit, sed ?
                                </h6>
                            </div>
                            <div className="card-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodas temporo incididunt ut labore et dolore magna aliqua.</div>
                        </div>
                    </div>
                </div>
                <div className="col-md-6 col-12 mt-5">
                    <div className="accordion">
                        <div className="card">
                            <div className="card-header">
                                <h6 className="mb-0">
                                    consectetur adipisicing elit, sed ?
                            </h6>
                            </div>
                            <div className="card-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodas temporo incididunt ut labore et dolore magna aliqua.</div>
                        </div>
                    </div>
                </div>
            </div>

        );
    }
}

export default TeamSection2;
